// Roda dentro da página do Loterias Online (injetada pelo popup). Precisa ser autocontida.
// o.game = { id, label, first, total }  (ex.: Mega-Sena: first 1, total 60)
async function runInPage(games, o) {
  if (!/caixa\.gov\.br$/.test(location.hostname)) return { ok: false, msg: "Esta aba não é do site da Caixa." };
  if (window.__lotoRunning) return { ok: false, msg: "Já há um preenchimento em andamento nesta aba." };
  const G = o.game;
  const last = G.first + G.total - 1;
  const $ = (id) => document.getElementById(id);
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const pad = (n) => (n < 10 ? "0" + n : "" + n);
  const val = (e) => parseInt(e.textContent.trim(), 10);

  // Se a aba estiver claramente em outra modalidade, avisa antes de clicar em qualquer coisa.
  const slugs = { lotomania: /lotomania/i, megasena: /mega-?sena/i, lotofacil: /lotofacil|lotof%C3%A1cil|lotofácil/i };
  const here = Object.keys(slugs).find((k) => slugs[k].test(location.href));
  if (here && here !== G.id) return { ok: false, msg: "A aba aberta parece ser de outra modalidade. Abra o volante de " + G.label + " ou troque a modalidade na extensão." };

  // Plano B: se os ids nXX não existirem, procura o bloco com todos os números do volante.
  function gridMap() {
    const leaves = [...document.querySelectorAll("body *")].filter(
      (e) => e.childElementCount === 0 && /^\d{1,2}$/.test(e.textContent.trim()) && e.offsetParent !== null);
    let best = null, size = Infinity;
    for (const e of leaves) {
      for (let p = e.parentElement; p && p !== document.documentElement; p = p.parentElement) {
        const inside = leaves.filter((l) => p.contains(l));
        const vals = inside.map(val);
        const distinct = new Set(vals);
        if (vals.every((v) => v >= G.first && v <= last) && distinct.size === G.total) {
          if (inside.length < size) { size = inside.length; best = p; }
          break;
        }
        if (vals.some((v) => v < G.first || v > last)) break; // passou do volante
      }
    }
    if (!best) return null;
    const m = new Map();
    leaves.filter((l) => best.contains(l)).forEach((l) => { if (!m.has(val(l))) m.set(val(l), l); });
    return m;
  }
  const firstId = "n" + pad(G.first);
  let fallback = null;
  const cell = (n) => $("n" + pad(n)) || (fallback && fallback.get(n));
  if (!$(firstId)) fallback = gridMap();
  if (!$("limparvolante") && !$(firstId) && !fallback) return { ok: false, msg: "Abra o volante de " + G.label + " no site primeiro." };

  let cancel = false;
  const box = document.createElement("div");
  box.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#1f2025;color:#f0f1f4;padding:10px 14px;border-radius:10px;font:14px system-ui,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.4)";
  const txt = document.createElement("span");
  const stop = document.createElement("button");
  stop.textContent = "Cancelar";
  stop.style.cssText = "margin-left:12px;cursor:pointer";
  stop.onclick = () => { cancel = true; };
  box.append(txt, stop);
  document.body.appendChild(box);

  window.__lotoRunning = true;
  let res = { ok: true, done: 0, total: games.length };
  const click = (id) => { const e = $(id); if (e) e.click(); return !!e; };
  try {
    for (let i = 0; i < games.length && !cancel; i++) {
      txt.textContent = G.label + ": jogo " + (i + 1) + " de " + games.length;
      click("limparvolante"); await wait(250);
      if (o.espelho && G.id === "lotomania") { click("apostaEspelho"); await wait(150); }
      for (let k = 0; k < o.teimosinha; k++) {
        if (!click("aumentarteimosinha")) { res.warn = "Não achei o botão da teimosinha nesta modalidade; ela não foi aplicada."; break; }
        await wait(80);
      }
      const missing = [];
      for (const n of games[i]) { const e = cell(n); if (e) e.click(); else missing.push(n); await wait(40); }
      if (missing.length) {
        res = { ...res, ok: false, msg: "Jogo " + (i + 1) + ": não achei os números " + missing.map(pad).join(", ") + ". Parei aqui." };
        break;
      }
      if (o.cart) {
        await wait(250);
        const id = o.espelho && G.id === "lotomania" && $("colocarnocarrinhoapostaEspelho") ? "colocarnocarrinhoapostaEspelho" : "colocarnocarrinho";
        const b = $(id);
        if (!b) { res = { ...res, ok: false, msg: "Jogo " + (i + 1) + " marcado, mas não achei o botão " + id + ". Parei aqui." }; break; }
        if (b.disabled || b.getAttribute("aria-disabled") === "true") { res = { ...res, ok: false, msg: "Jogo " + (i + 1) + " marcado, mas o botão do carrinho está desabilitado. Parei aqui." }; break; }
        b.click();
        await wait(600);
      }
      res.done = i + 1;
    }
    if (cancel) res.cancelled = true;
  } finally {
    window.__lotoRunning = false;
    box.remove();
  }
  return res;
}
