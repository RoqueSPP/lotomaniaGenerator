const $ = (id) => document.getElementById(id);
let games = [];

function parse(text) {
  return text.split(/\r?\n/).map((l) => l.replace(/^\s*jogo\s*\d+\s*:/i, ""))
    .map((l) => (l.match(/\d{1,2}/g) || []).map(Number))
    .filter((a) => a.length)
    .map((a) => [...new Set(a)].sort((x, y) => x - y));
}
const valid = (g) => g.length === 50 && g.every((n) => n >= 0 && n <= 99);
const say = (t, cls) => { $("msg").textContent = t; $("msg").className = cls || ""; };
const save = () => chrome.storage.local.set({ txt: $("txt").value, act: $("act").value, tz: $("tz").value, esp: $("esp").checked });

function refresh(keep) {
  games = parse($("txt").value);
  const sel = $("sel");
  sel.innerHTML = "";
  games.forEach((g, i) => {
    const o = document.createElement("option");
    o.value = i;
    o.textContent = "Jogo " + (i + 1) + (valid(g) ? "" : " (" + g.length + " números, inválido)");
    sel.appendChild(o);
  });
  if (keep != null && keep < games.length) sel.value = keep;
  $("go").disabled = $("all").disabled = !games.length;
  save();
}

async function start(list, cart, label) {
  const opts = { espelho: $("esp").checked, teimosinha: Number($("tz").value), cart };
  $("go").disabled = $("all").disabled = true;
  say(label + " Acompanhe pela caixa no canto da página do site.");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: runInPage, args: [list, opts] });
    const r = res.result || { ok: false, msg: "Sem resposta da página." };
    if (!r.ok) say(r.msg, "err");
    else if (r.cancelled) say("Cancelado após " + r.done + " de " + r.total + " jogos.", "err");
    else say(r.done + (r.done > 1 ? " jogos processados" : " jogo processado") + (cart ? " e enviados ao carrinho" : "") + ". Confira no site e pague por lá.", "ok");
    return r;
  } catch (e) {
    say("Erro: " + e.message, "err");
  } finally {
    $("go").disabled = $("all").disabled = !games.length;
  }
}

$("go").addEventListener("click", async () => {
  const i = Number($("sel").value);
  if (!valid(games[i])) return say("O jogo " + (i + 1) + " precisa ter 50 números diferentes entre 00 e 99.", "err");
  const r = await start([games[i]], $("act").value === "cart", "Marcando o jogo " + (i + 1) + "…");
  if (r && r.ok && !r.cancelled && i + 1 < games.length) $("sel").value = i + 1;
});

$("all").addEventListener("click", () => {
  const bad = games.findIndex((g) => !valid(g));
  if (bad > -1) return say("O jogo " + (bad + 1) + " é inválido. Corrija antes de preencher todos.", "err");
  if (!confirm("Colocar " + games.length + " jogo(s) no carrinho do site? O pagamento continua com você.")) return;
  start(games, true, "Preenchendo " + games.length + " jogo(s)…");
});

["input", "change"].forEach((ev) => document.addEventListener(ev, (e) => { if (e.target.id === "txt") refresh(); else if (["act", "tz", "esp"].includes(e.target.id)) save(); }));
chrome.storage.local.get(["txt", "act", "tz", "esp"], (d) => {
  if (d.txt) $("txt").value = d.txt;
  if (d.act) $("act").value = d.act;
  if (d.tz) $("tz").value = d.tz;
  $("esp").checked = !!d.esp;
  refresh();
});
