const $ = (id) => document.getElementById(id);
const GAMES = {
  lotomania: { id: "lotomania", label: "Lotomania", first: 0, total: 100, min: 50, max: 50, re: /lotomania/i },
  megasena: { id: "megasena", label: "Mega-Sena", first: 1, total: 60, min: 6, max: 20, re: /mega-?sena/i },
  lotofacil: { id: "lotofacil", label: "Lotofácil", first: 1, total: 25, min: 15, max: 20, re: /lotof[aá]cil|lotof%C3%A1cil/i },
};
let games = [];
const G = () => GAMES[$("game").value];

function detectInText(text) {
  const head = text.split(/\r?\n/).find((l) => l.trim()) || "";
  if (/\d/.test(head)) return null;
  return Object.keys(GAMES).find((k) => GAMES[k].re.test(head)) || null;
}
function parse(text) {
  return text.split(/\r?\n/).map((l) => l.replace(/^\s*jogo\s*\d+\s*:/i, ""))
    .map((l) => (l.match(/\d{1,2}/g) || []).map(Number))
    .filter((a) => a.length)
    .map((a) => [...new Set(a)].sort((x, y) => x - y));
}
const rule = (g) => (g.min === g.max ? g.min + " números diferentes" : "entre " + g.min + " e " + g.max + " números diferentes") + " de " + String(g.first).padStart(2, "0") + " a " + String(g.first + g.total - 1).padStart(2, "0");
const valid = (a) => { const g = G(); return a.length >= g.min && a.length <= g.max && a.every((n) => n >= g.first && n < g.first + g.total); };
const say = (t, cls) => { $("msg").textContent = t; $("msg").className = cls || ""; };
const save = () => chrome.storage.local.set({ txt: $("txt").value, act: $("act").value, tz: $("tz").value, esp: $("esp").checked, game: $("game").value });

function refresh(keep) {
  const g = G();
  $("espRow").style.display = g.id === "lotomania" ? "" : "none";
  games = parse($("txt").value);
  const sel = $("sel");
  sel.innerHTML = "";
  games.forEach((a, i) => {
    const o = document.createElement("option");
    o.value = i;
    o.textContent = "Jogo " + (i + 1) + (valid(a) ? "" : " (" + a.length + " números, inválido)");
    sel.appendChild(o);
  });
  if (keep != null && keep < games.length) sel.value = keep;
  $("go").disabled = $("all").disabled = !games.length;
  save();
}

async function start(list, cart, label) {
  const g = G();
  const opts = { game: { id: g.id, label: g.label, first: g.first, total: g.total }, espelho: g.id === "lotomania" && $("esp").checked, teimosinha: Number($("tz").value), cart };
  $("go").disabled = $("all").disabled = true;
  say(label + " Acompanhe pela caixa no canto da página do site.");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: runInPage, args: [list, opts] });
    const r = res.result || { ok: false, msg: "Sem resposta da página." };
    if (!r.ok) say(r.msg, "err");
    else if (r.cancelled) say("Cancelado após " + r.done + " de " + r.total + " jogos.", "err");
    else say(r.done + (r.done > 1 ? " jogos processados" : " jogo processado") + (cart ? " e enviados ao carrinho" : "") + ". Confira no site e pague por lá." + (r.warn ? " " + r.warn : ""), "ok");
    return r;
  } catch (e) {
    say("Erro: " + e.message, "err");
  } finally {
    $("go").disabled = $("all").disabled = !games.length;
  }
}

$("go").addEventListener("click", async () => {
  const i = Number($("sel").value);
  if (!valid(games[i])) return say("O jogo " + (i + 1) + " precisa ter " + rule(G()) + ".", "err");
  const r = await start([games[i]], $("act").value === "cart", "Marcando o jogo " + (i + 1) + "…");
  if (r && r.ok && !r.cancelled && i + 1 < games.length) $("sel").value = i + 1;
});

$("all").addEventListener("click", () => {
  const bad = games.findIndex((a) => !valid(a));
  if (bad > -1) return say("O jogo " + (bad + 1) + " é inválido para " + G().label + " (precisa ter " + rule(G()) + "). Corrija antes de preencher todos.", "err");
  if (!confirm("Colocar " + games.length + " jogo(s) de " + G().label + " no carrinho do site? O pagamento continua com você.")) return;
  start(games, true, "Preenchendo " + games.length + " jogo(s)…");
});

document.addEventListener("input", (e) => {
  if (e.target.id !== "txt") return;
  const d = detectInText($("txt").value);
  if (d) $("game").value = d;
  refresh();
});
document.addEventListener("change", (e) => {
  if (e.target.id === "game") refresh();
  else if (["act", "tz", "esp"].includes(e.target.id)) save();
});

chrome.storage.local.get(["txt", "act", "tz", "esp", "game"], async (d) => {
  if (d.txt) $("txt").value = d.txt;
  if (d.act) $("act").value = d.act;
  if (d.tz) $("tz").value = d.tz;
  $("esp").checked = !!d.esp;
  if (d.game && GAMES[d.game]) $("game").value = d.game;
  // A modalidade do texto colado ou da aba aberta tem prioridade sobre a última escolha.
  let found = detectInText($("txt").value);
  if (!found) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      found = Object.keys(GAMES).find((k) => GAMES[k].re.test(tab.url || "")) || null;
    } catch (e) {}
  }
  if (found) $("game").value = found;
  refresh();
});
